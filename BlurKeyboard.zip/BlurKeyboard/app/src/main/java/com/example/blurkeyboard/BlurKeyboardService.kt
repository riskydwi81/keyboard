package com.example.blurkeyboard

import android.animation.ValueAnimator
import android.graphics.RenderEffect
import android.graphics.Shader
import android.inputmethodservice.InputMethodService
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.animation.LinearInterpolator
import android.widget.Button
import android.widget.LinearLayout

/**
 * IME custom dengan efek blur dinamis mirip iOS.
 *
 * Dua lapis blur dipakai di sini:
 * 1. Window "blur behind" (WindowManager.LayoutParams.setBlurBehindRadius) -
 *    ini yang mem-blur konten APLIKASI DI BELAKANG keyboard (efek frosted glass
 *    ala iOS keyboard). Butuh Android 12+ (API 31) dan device yang mendukung
 *    cross-window blur.
 * 2. Radius blur dianimasikan naik-turun saat keyboard muncul/hilang supaya
 *    terasa "dinamis", bukan statis.
 */
class BlurKeyboardService : InputMethodService() {

    private val maxBlurRadius = 40 // dalam pixel, sesuaikan selera
    private var blurAnimator: ValueAnimator? = null

    private val letterRows = listOf(
        "q w e r t y u i o p",
        "a s d f g h j k l",
        "z x c v b n m"
    )

    override fun onCreateInputView(): View {
        val view = LayoutInflater.from(this).inflate(R.layout.keyboard_view, null)

        val row1 = view.findViewById<LinearLayout>(R.id.row1)
        val row2 = view.findViewById<LinearLayout>(R.id.row2)
        val row3 = view.findViewById<LinearLayout>(R.id.row3)
        val row4 = view.findViewById<LinearLayout>(R.id.row4)

        populateLetterRow(row1, letterRows[0])
        populateLetterRow(row2, letterRows[1])

        // Baris 3: huruf + backspace
        populateLetterRow(row3, letterRows[2])
        addSpecialKey(row3, "⌫", weight = 1.5f) {
            currentInputConnection?.deleteSurroundingText(1, 0)
        }

        // Baris 4: 123, koma, spasi, titik, enter
        addSpecialKey(row4, "123", weight = 1.2f) { /* TODO: switch ke layout angka */ }
        addSpecialKey(row4, ",", weight = 0.8f) {
            currentInputConnection?.commitText(",", 1)
        }
        addSpecialKey(row4, "␣", weight = 4f) {
            currentInputConnection?.commitText(" ", 1)
        }
        addSpecialKey(row4, ".", weight = 0.8f) {
            currentInputConnection?.commitText(".", 1)
        }
        addSpecialKey(row4, "⏎", weight = 1.2f) {
            currentInputConnection?.commitText("\n", 1)
        }

        // Blur konten di dalam view keyboard sendiri (opsional, RenderEffect)
        // - ini memblur apa pun yang digambar DI BAWAH view ini dalam hierarchy-nya sendiri.
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            view.setRenderEffect(
                RenderEffect.createBlurEffect(6f, 6f, Shader.TileMode.CLAMP)
            )
        }

        return view
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        applyWindowBlurBehind()
    }

    override fun onFinishInputView(finishingInput: Boolean) {
        super.onFinishInputView(finishingInput)
        blurAnimator?.cancel()
    }

    /**
     * Menerapkan blur pada window di BELAKANG keyboard (konten aplikasi host),
     * dianimasikan dari 0 ke maxBlurRadius supaya terasa "muncul" secara halus,
     * mirip transisi keyboard iOS.
     */
    private fun applyWindowBlurBehind() {
        val w = window?.window ?: return

        // Cek dukungan device. Beberapa custom ROM (termasuk sebagian HyperOS)
        // bisa mematikan ini lewat setting hemat baterai/animasi.
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val supported = if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.S) {
            wm.isCrossWindowBlurEnabled
        } else false

        if (!supported) return

        w.addFlags(WindowManager.LayoutParams.FLAG_BLUR_BEHIND)

        blurAnimator?.cancel()
        blurAnimator = ValueAnimator.ofInt(0, maxBlurRadius).apply {
            duration = 220
            interpolator = LinearInterpolator()
            addUpdateListener { anim ->
                val radius = anim.animatedValue as Int
                val attrs = w.attributes
                attrs.blurBehindRadius = radius
                w.attributes = attrs
            }
            start()
        }
    }

    private fun populateLetterRow(row: LinearLayout, letters: String) {
        letters.split(" ").forEach { letter ->
            addSpecialKey(row, letter, weight = 1f) {
                currentInputConnection?.commitText(letter, 1)
            }
        }
    }

    private fun addSpecialKey(
        row: LinearLayout,
        label: String,
        weight: Float,
        onClick: () -> Unit
    ) {
        val btn = Button(this).apply {
            text = label
            isAllCaps = false
            setBackgroundResource(R.drawable.key_background)
            setTextColor(resources.getColor(R.color.key_text, theme))
            setOnClickListener { onClick() }
        }
        row.addView(
            btn,
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, weight).apply {
                marginStart = 3
                marginEnd = 3
            }
        )
    }
}
