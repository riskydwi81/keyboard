package com.example.blurkeyboard

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

/**
 * Activity ini bukan bagian dari keyboard itu sendiri.
 * Fungsinya cuma membantu user mengaktifkan & memilih Blur Keyboard,
 * karena IME tidak bisa diaktifkan langsung dari kode tanpa campur tangan user
 * (ini pembatasan keamanan Android).
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(48, 96, 48, 48)
        }

        val text = TextView(this).apply {
            text = getString(R.string.setup_instructions)
            textSize = 16f
        }

        val btnSettings = Button(this).apply {
            text = getString(R.string.open_ime_settings)
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_INPUT_METHOD_SETTINGS))
            }
        }

        val btnSwitch = Button(this).apply {
            text = getString(R.string.switch_keyboard)
            setOnClickListener {
                val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
                imm.showInputMethodPicker()
            }
        }

        root.addView(text)
        root.addView(btnSettings, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 48 })
        root.addView(btnSwitch, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = 24 })

        setContentView(root)
    }
}
