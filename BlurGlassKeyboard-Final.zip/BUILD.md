# BlurGlass Keyboard

Android IME keyboard project generated from the AI Studio source.

Build locally:
`gradle :app:assembleDebug`

GitHub Actions:
`.github/workflows/build-apk.yml`

The keyboard is an offline Android InputMethodService. The visual glass/blur effect is implemented in the UI layer with fallbacks for devices that do not expose cross-window blur.
