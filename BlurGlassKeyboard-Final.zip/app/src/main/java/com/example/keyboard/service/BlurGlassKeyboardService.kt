package com.example.keyboard.service

import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.os.Bundle
import android.os.CombinedVibration
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.view.KeyEvent
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputConnection
import android.inputmethodservice.InputMethodService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.example.keyboard.model.ActionKeyInfo
import com.example.keyboard.model.GlassThemes
import com.example.keyboard.model.KeyboardPreferences
import com.example.keyboard.model.KeyboardThemeType
import com.example.keyboard.ui.KeyboardScreen

class BlurGlassKeyboardService : InputMethodService(),
    LifecycleOwner,
    ViewModelStoreOwner,
    SavedStateRegistryOwner {

    private val lifecycleRegistry by lazy { LifecycleRegistry(this) }
    private val savedStateRegistryController by lazy { SavedStateRegistryController.create(this) }
    private val store = ViewModelStore()

    override val lifecycle: Lifecycle get() = lifecycleRegistry
    override val viewModelStore: ViewModelStore get() = store
    override val savedStateRegistry: SavedStateRegistry get() = savedStateRegistryController.savedStateRegistry

    private lateinit var preferences: KeyboardPreferences
    private var actionInfo by mutableStateOf(ActionKeyInfo(EditorInfo.IME_ACTION_NONE, "return", false))
    private var currentThemeType by mutableStateOf(KeyboardThemeType.MIDNIGHT_OBSIDIAN)
    private var hapticEnabled by mutableStateOf(true)
    private var hapticStrength by mutableStateOf(2)
    private var soundEnabled by mutableStateOf(true)
    private var keyPopupEnabled by mutableStateOf(true)
    private var doubleSpacePeriod by mutableStateOf(true)
    private var autoCapitalize by mutableStateOf(true)

    private val vibrator: Vibrator? by lazy {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
    }

    private val audioManager: AudioManager? by lazy {
        getSystemService(Context.AUDIO_SERVICE) as? AudioManager
    }

    private val clipboardManager: ClipboardManager? by lazy {
        getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
    }

    override fun onCreate() {
        super.onCreate()
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)

        preferences = KeyboardPreferences(this)
        loadPreferences()
    }

    private fun loadPreferences() {
        currentThemeType = preferences.themeType
        hapticEnabled = preferences.hapticFeedback
        hapticStrength = preferences.hapticStrength
        soundEnabled = preferences.soundFeedback
        keyPopupEnabled = preferences.keyPopupPreview
        doubleSpacePeriod = preferences.doubleSpacePeriod
        autoCapitalize = preferences.autoCapitalize
    }

    override fun onCreateInputView(): View {
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        loadPreferences()

        val composeView = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@BlurGlassKeyboardService)
            setViewTreeViewModelStoreOwner(this@BlurGlassKeyboardService)
            setViewTreeSavedStateRegistryOwner(this@BlurGlassKeyboardService)
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindowOrReleasedFromPool)

            setContent {
                val theme = GlassThemes.getTheme(currentThemeType)
                KeyboardScreen(
                    currentTheme = theme,
                    actionInfo = actionInfo,
                    showPopupPreview = keyPopupEnabled,
                    doubleSpacePeriod = doubleSpacePeriod,
                    autoCapitalize = autoCapitalize,
                    onCommitText = { text -> commitText(text) },
                    onDelete = { deleteCharacter() },
                    onAction = { handleAction() },
                    onSwitchIme = { switchIme() },
                    onHideKeyboard = { requestHideSelf(0) },
                    onMoveCursor = { offset -> moveCursor(offset) },
                    onPaste = { pasteFromClipboard() },
                    onPlayHaptic = { playHapticFeedback() },
                    onPlaySound = { playSoundFeedback() },
                    onThemeChange = { newThemeType ->
                        currentThemeType = newThemeType
                        preferences.themeType = newThemeType
                    }
                )
            }
        }
        return composeView
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        loadPreferences()
        actionInfo = ActionKeyInfo.fromEditorInfo(info)
    }

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }

    private fun commitText(text: String) {
        currentInputConnection?.commitText(text, 1)
    }

    private fun deleteCharacter() {
        val ic = currentInputConnection ?: return
        val selectedText = ic.getSelectedText(0)
        if (selectedText.isNullOrEmpty()) {
            // Delete one character before cursor
            val deleted = ic.deleteSurroundingText(1, 0)
            if (!deleted) {
                // Fallback to key event delete
                sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
            }
        } else {
            // If text is selected, replace selection with empty string
            ic.commitText("", 1)
        }
    }

    private fun handleAction() {
        val ic = currentInputConnection ?: return
        if (actionInfo.actionId != EditorInfo.IME_ACTION_NONE && actionInfo.actionId != EditorInfo.IME_ACTION_UNSPECIFIED) {
            val performed = ic.performEditorAction(actionInfo.actionId)
            if (!performed) {
                sendKeyChar('\n')
            }
        } else {
            sendKeyChar('\n')
        }
    }

    private fun switchIme() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val switched = switchToNextInputMethod(false)
            if (!switched) {
                // Fallback to showing input method picker
                val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as? android.view.inputmethod.InputMethodManager
                imm?.showInputMethodPicker()
            }
        } else {
            @Suppress("DEPRECATION")
            switchToNextInputMethod(false)
        }
    }

    private fun moveCursor(offset: Int) {
        val ic = currentInputConnection ?: return
        if (offset < 0) {
            // Move cursor left
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_LEFT)
        } else if (offset > 0) {
            // Move cursor right
            sendDownUpKeyEvents(KeyEvent.KEYCODE_DPAD_RIGHT)
        }
    }

    private fun pasteFromClipboard() {
        val cm = clipboardManager ?: return
        if (cm.hasPrimaryClip()) {
            val item = cm.primaryClip?.getItemAt(0)
            val text = item?.coerceToText(this)?.toString()
            if (!text.isNullOrEmpty()) {
                commitText(text)
            }
        }
    }

    private fun playHapticFeedback() {
        if (!hapticEnabled) return
        try {
            val duration = when (hapticStrength) {
                1 -> 10L // Soft iOS tap
                2 -> 18L // Medium iOS click
                3 -> 30L // Firm feedback
                else -> 18L
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                vibrator?.vibrate(
                    VibrationEffect.createPredefined(VibrationEffect.EFFECT_CLICK)
                )
            } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(duration, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(duration)
            }
        } catch (e: Exception) {
            // Ignore if vibration fails or is unsupported on device
        }
    }

    private fun playSoundFeedback() {
        if (!soundEnabled) return
        try {
            audioManager?.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD, 0.5f)
        } catch (e: Exception) {
            // Ignore sound failures
        }
    }
}
