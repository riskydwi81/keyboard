package com.example.keyboard.model

import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

/**
 * Keyboard theme definitions with realistic Glassmorphism styling.
 */
enum class KeyboardThemeType(
    val displayName: String,
    val description: String
) {
    MIDNIGHT_OBSIDIAN("Midnight Obsidian", "Smoked dark frosted glass with luminous typography"),
    FROSTED_CRYSTAL("Frosted Crystal", "iOS light frosted glass with clean contrast"),
    AURORA_PRISM("Aurora Prism", "Prismatic holographic glass with subtle cosmic refraction"),
    CYBER_TITANIUM("Cyber Titanium", "Deep frosted metallic glass with neon aqua accents")
}

data class GlassTheme(
    val type: KeyboardThemeType,
    val backgroundBrush: Brush,
    val backgroundOverlay: Color,
    val keyBrush: Brush,
    val keyPressedBrush: Brush,
    val specialKeyBrush: Brush,
    val specialKeyPressedBrush: Brush,
    val actionKeyBrush: Brush,
    val actionKeyPressedBrush: Brush,
    val keyBorderColor: Color,
    val keyTopHighlightColor: Color,
    val keyTextColor: Color,
    val specialKeyTextColor: Color,
    val actionKeyTextColor: Color,
    val popupBubbleBg: Color,
    val popupTextColor: Color,
    val toolbarIconColor: Color,
    val isDark: Boolean
)

object GlassThemes {
    val MidnightObsidian = GlassTheme(
        type = KeyboardThemeType.MIDNIGHT_OBSIDIAN,
        backgroundBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xEE1E2029),
                Color(0xF514161E),
                Color(0xFA0E1017)
            )
        ),
        backgroundOverlay = Color(0x33FFFFFF),
        keyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x38FFFFFF),
                Color(0x1FFFFFFF)
            )
        ),
        keyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x55FFFFFF),
                Color(0x3DFFFFFF)
            )
        ),
        specialKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x22FFFFFF),
                Color(0x12FFFFFF)
            )
        ),
        specialKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x44FFFFFF),
                Color(0x28FFFFFF)
            )
        ),
        actionKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF007AFF),
                Color(0xFF0056B3)
            )
        ),
        actionKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF3395FF),
                Color(0xFF006BE6)
            )
        ),
        keyBorderColor = Color(0x40FFFFFF),
        keyTopHighlightColor = Color(0x66FFFFFF),
        keyTextColor = Color(0xFFF5F5F7),
        specialKeyTextColor = Color(0xFFD1D1D6),
        actionKeyTextColor = Color.White,
        popupBubbleBg = Color(0xF02A2D3A),
        popupTextColor = Color.White,
        toolbarIconColor = Color(0xCCEBEBF5),
        isDark = true
    )

    val FrostedCrystal = GlassTheme(
        type = KeyboardThemeType.FROSTED_CRYSTAL,
        backgroundBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xEEEDF0F5),
                Color(0xF5E3E7EE),
                Color(0xFAD6DBE4)
            )
        ),
        backgroundOverlay = Color(0x44FFFFFF),
        keyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xF5FFFFFF),
                Color(0xEBFFFFFF)
            )
        ),
        keyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xCCFFFFFF),
                Color(0xB3ECEEF2)
            )
        ),
        specialKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x40B0B8C4),
                Color(0x2EB0B8C4)
            )
        ),
        specialKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x60B0B8C4),
                Color(0x4DB0B8C4)
            )
        ),
        actionKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF007AFF),
                Color(0xFF0062CC)
            )
        ),
        actionKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF3395FF),
                Color(0xFF0070EB)
            )
        ),
        keyBorderColor = Color(0x40FFFFFF),
        keyTopHighlightColor = Color(0x99FFFFFF),
        keyTextColor = Color(0xFF1D1D1F),
        specialKeyTextColor = Color(0xFF2C2C2E),
        actionKeyTextColor = Color.White,
        popupBubbleBg = Color(0xF5FFFFFF),
        popupTextColor = Color(0xFF1C1C1E),
        toolbarIconColor = Color(0xFF3C3C43),
        isDark = false
    )

    val AuroraPrism = GlassTheme(
        type = KeyboardThemeType.AURORA_PRISM,
        backgroundBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xEE1A142D),
                Color(0xF5131838),
                Color(0xFA0B1024)
            )
        ),
        backgroundOverlay = Color(0x33A78BFA),
        keyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x358B5CF6),
                Color(0x203B82F6)
            )
        ),
        keyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x55A78BFA),
                Color(0x3860A5FA)
            )
        ),
        specialKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x224C1D95),
                Color(0x1A1E1B4B)
            )
        ),
        specialKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x446D28D9),
                Color(0x2E312E81)
            )
        ),
        actionKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF8B5CF6),
                Color(0xFF6366F1)
            )
        ),
        actionKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFFA78BFA),
                Color(0xFF818CF8)
            )
        ),
        keyBorderColor = Color(0x55C084FC),
        keyTopHighlightColor = Color(0x88E879F9),
        keyTextColor = Color(0xFFFDF4FF),
        specialKeyTextColor = Color(0xFFE9D5FF),
        actionKeyTextColor = Color.White,
        popupBubbleBg = Color(0xF02E1065),
        popupTextColor = Color(0xFFFAF5FF),
        toolbarIconColor = Color(0xFFE9D5FF),
        isDark = true
    )

    val CyberTitanium = GlassTheme(
        type = KeyboardThemeType.CYBER_TITANIUM,
        backgroundBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xEE0A1926),
                Color(0xF506111B),
                Color(0xFA040B12)
            )
        ),
        backgroundOverlay = Color(0x3306B6D4),
        keyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x2B14B8A6),
                Color(0x180E7490)
            )
        ),
        keyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x4D2DD4BF),
                Color(0x3322D3EE)
            )
        ),
        specialKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x200F172A),
                Color(0x15164E63)
            )
        ),
        specialKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0x3B1E293B),
                Color(0x280E7490)
            )
        ),
        actionKeyBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF06B6D4),
                Color(0xFF0891B2)
            )
        ),
        actionKeyPressedBrush = Brush.verticalGradient(
            colors = listOf(
                Color(0xFF22D3EE),
                Color(0xFF06B6D4)
            )
        ),
        keyBorderColor = Color(0x4D22D3EE),
        keyTopHighlightColor = Color(0x8067E8F9),
        keyTextColor = Color(0xFFECFEFF),
        specialKeyTextColor = Color(0xFFCFFAFE),
        actionKeyTextColor = Color(0xFF042F2E),
        popupBubbleBg = Color(0xF0083344),
        popupTextColor = Color(0xFFECFEFF),
        toolbarIconColor = Color(0xFF67E8F9),
        isDark = true
    )

    fun getTheme(type: KeyboardThemeType): GlassTheme {
        return when (type) {
            KeyboardThemeType.MIDNIGHT_OBSIDIAN -> MidnightObsidian
            KeyboardThemeType.FROSTED_CRYSTAL -> FrostedCrystal
            KeyboardThemeType.AURORA_PRISM -> AuroraPrism
            KeyboardThemeType.CYBER_TITANIUM -> CyberTitanium
        }
    }
}
