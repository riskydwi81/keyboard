package com.example.keyboard.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Backspace
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.ContentPaste
import androidx.compose.material.icons.filled.Done
import androidx.compose.material.icons.filled.FormatPaint
import androidx.compose.material.icons.filled.KeyboardHide
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Mood
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.keyboard.model.ActionKeyInfo
import com.example.keyboard.model.EmojiData
import com.example.keyboard.model.GlassTheme
import com.example.keyboard.model.GlassThemes
import com.example.keyboard.model.KeyboardLayoutMode
import com.example.keyboard.model.KeyboardThemeType
import com.example.keyboard.model.ShiftState

@Composable
fun KeyboardScreen(
    currentTheme: GlassTheme,
    actionInfo: ActionKeyInfo,
    showPopupPreview: Boolean = true,
    doubleSpacePeriod: Boolean = true,
    autoCapitalize: Boolean = true,
    onCommitText: (String) -> Unit,
    onDelete: () -> Unit,
    onAction: () -> Unit,
    onSwitchIme: () -> Unit,
    onHideKeyboard: () -> Unit,
    onMoveCursor: (Int) -> Unit,
    onPaste: () -> Unit,
    onPlayHaptic: () -> Unit,
    onPlaySound: () -> Unit,
    onThemeChange: (KeyboardThemeType) -> Unit,
    modifier: Modifier = Modifier
) {
    var layoutMode by remember { mutableStateOf(KeyboardLayoutMode.LETTERS) }
    var shiftState by remember { mutableStateOf(ShiftState.UPPERCASE) }
    var selectedEmojiCategoryIndex by remember { mutableStateOf(0) }
    var showThemeMenu by remember { mutableStateOf(false) }

    fun triggerKeyFeedback() {
        onPlayHaptic()
        onPlaySound()
    }

    fun handleCharacterInput(char: String) {
        triggerKeyFeedback()
        val textToCommit = if (shiftState.isUppercase()) char.uppercase() else char.lowercase()
        onCommitText(textToCommit)

        // Single uppercase return to lowercase unless CAPS_LOCK
        if (shiftState == ShiftState.UPPERCASE) {
            shiftState = ShiftState.LOWERCASE
        }
    }

    // Outer Glass Container with Frosted Blur Styling
    Box(
        modifier = modifier
            .fillMaxWidth()
            .background(brush = currentTheme.backgroundBrush)
            .border(
                width = 1.dp,
                color = currentTheme.keyTopHighlightColor.copy(alpha = 0.3f),
                shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)
            )
            .drawBehind {
                // Subtle glowing top accent line
                drawLine(
                    color = currentTheme.keyTopHighlightColor.copy(alpha = 0.6f),
                    start = Offset(0f, 0f),
                    end = Offset(size.width, 0f),
                    strokeWidth = 2.dp.toPx()
                )
            }
            .navigationBarsPadding()
            .padding(bottom = 6.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 3.dp, vertical = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 1. Frosted Glass Top Quick Action Toolbar
            KeyboardTopBar(
                currentTheme = currentTheme,
                isEmojiMode = layoutMode == KeyboardLayoutMode.EMOJI,
                onToggleEmoji = {
                    triggerKeyFeedback()
                    layoutMode = if (layoutMode == KeyboardLayoutMode.EMOJI) {
                        KeyboardLayoutMode.LETTERS
                    } else {
                        KeyboardLayoutMode.EMOJI
                    }
                },
                onToggleThemeMenu = {
                    triggerKeyFeedback()
                    showThemeMenu = !showThemeMenu
                },
                onMoveCursor = { offset ->
                    triggerKeyFeedback()
                    onMoveCursor(offset)
                },
                onPaste = {
                    triggerKeyFeedback()
                    onPaste()
                },
                onHideKeyboard = {
                    triggerKeyFeedback()
                    onHideKeyboard()
                }
            )

            // Theme Switcher Quick Bar Popup
            AnimatedVisibility(
                visible = showThemeMenu,
                enter = fadeIn(),
                exit = fadeOut()
            ) {
                ThemeSelectorBar(
                    currentTheme = currentTheme,
                    onSelectTheme = { themeType ->
                        triggerKeyFeedback()
                        onThemeChange(themeType)
                        showThemeMenu = false
                    }
                )
            }

            // 2. Keyboard Main Layout Views
            when (layoutMode) {
                KeyboardLayoutMode.LETTERS -> {
                    LettersKeyboardLayout(
                        theme = currentTheme,
                        shiftState = shiftState,
                        actionInfo = actionInfo,
                        showPopupPreview = showPopupPreview,
                        doubleSpacePeriod = doubleSpacePeriod,
                        onKeyInput = { char -> handleCharacterInput(char) },
                        onShiftClick = {
                            triggerKeyFeedback()
                            shiftState = when (shiftState) {
                                ShiftState.LOWERCASE -> ShiftState.UPPERCASE
                                ShiftState.UPPERCASE -> ShiftState.LOWERCASE
                                ShiftState.CAPS_LOCK -> ShiftState.LOWERCASE
                            }
                        },
                        onShiftDoubleTap = {
                            triggerKeyFeedback()
                            shiftState = ShiftState.CAPS_LOCK
                        },
                        onBackspaceClick = {
                            triggerKeyFeedback()
                            onDelete()
                        },
                        onSwitchLayout = { targetMode ->
                            triggerKeyFeedback()
                            layoutMode = targetMode
                        },
                        onSpaceClick = {
                            triggerKeyFeedback()
                            onCommitText(" ")
                        },
                        onSpaceDoubleTap = {
                            if (doubleSpacePeriod) {
                                triggerKeyFeedback()
                                onDelete()
                                onCommitText(". ")
                                if (autoCapitalize) {
                                    shiftState = ShiftState.UPPERCASE
                                }
                            } else {
                                triggerKeyFeedback()
                                onCommitText(" ")
                            }
                        },
                        onPeriodClick = {
                            triggerKeyFeedback()
                            onCommitText(".")
                            if (autoCapitalize) {
                                shiftState = ShiftState.UPPERCASE
                            }
                        },
                        onActionClick = {
                            triggerKeyFeedback()
                            onAction()
                        },
                        onSwitchIme = {
                            triggerKeyFeedback()
                            onSwitchIme()
                        }
                    )
                }

                KeyboardLayoutMode.NUMBERS_SYMBOLS -> {
                    NumbersSymbolsKeyboardLayout(
                        theme = currentTheme,
                        actionInfo = actionInfo,
                        showPopupPreview = showPopupPreview,
                        onKeyInput = { char ->
                            triggerKeyFeedback()
                            onCommitText(char)
                        },
                        onBackspaceClick = {
                            triggerKeyFeedback()
                            onDelete()
                        },
                        onSwitchLayout = { targetMode ->
                            triggerKeyFeedback()
                            layoutMode = targetMode
                        },
                        onSpaceClick = {
                            triggerKeyFeedback()
                            onCommitText(" ")
                        },
                        onActionClick = {
                            triggerKeyFeedback()
                            onAction()
                        },
                        onSwitchIme = {
                            triggerKeyFeedback()
                            onSwitchIme()
                        }
                    )
                }

                KeyboardLayoutMode.MORE_SYMBOLS -> {
                    MoreSymbolsKeyboardLayout(
                        theme = currentTheme,
                        actionInfo = actionInfo,
                        showPopupPreview = showPopupPreview,
                        onKeyInput = { char ->
                            triggerKeyFeedback()
                            onCommitText(char)
                        },
                        onBackspaceClick = {
                            triggerKeyFeedback()
                            onDelete()
                        },
                        onSwitchLayout = { targetMode ->
                            triggerKeyFeedback()
                            layoutMode = targetMode
                        },
                        onSpaceClick = {
                            triggerKeyFeedback()
                            onCommitText(" ")
                        },
                        onActionClick = {
                            triggerKeyFeedback()
                            onAction()
                        },
                        onSwitchIme = {
                            triggerKeyFeedback()
                            onSwitchIme()
                        }
                    )
                }

                KeyboardLayoutMode.EMOJI -> {
                    EmojiKeyboardLayout(
                        theme = currentTheme,
                        selectedCategoryIndex = selectedEmojiCategoryIndex,
                        onSelectCategory = { index ->
                            triggerKeyFeedback()
                            selectedEmojiCategoryIndex = index
                        },
                        onEmojiClick = { emoji ->
                            triggerKeyFeedback()
                            onCommitText(emoji)
                        },
                        onBackspaceClick = {
                            triggerKeyFeedback()
                            onDelete()
                        },
                        onReturnToLetters = {
                            triggerKeyFeedback()
                            layoutMode = KeyboardLayoutMode.LETTERS
                        },
                        onSpaceClick = {
                            triggerKeyFeedback()
                            onCommitText(" ")
                        }
                    )
                }
            }
        }
    }
}

/**
 * Frosted Glass Header Toolbar with quick utilities
 */
@Composable
private fun KeyboardTopBar(
    currentTheme: GlassTheme,
    isEmojiMode: Boolean,
    onToggleEmoji: () -> Unit,
    onToggleThemeMenu: () -> Unit,
    onMoveCursor: (Int) -> Unit,
    onPaste: () -> Unit,
    onHideKeyboard: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(38.dp)
            .padding(horizontal = 8.dp, vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left side quick tools
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Theme pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(currentTheme.specialKeyBrush)
                    .border(0.6.dp, currentTheme.keyBorderColor, RoundedCornerShape(12.dp))
                    .clickable { onToggleThemeMenu() }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.FormatPaint,
                        contentDescription = "Themes",
                        tint = currentTheme.toolbarIconColor,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "Theme",
                        color = currentTheme.toolbarIconColor,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            // Emoji / ABC toggle
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (isEmojiMode) currentTheme.actionKeyBrush else currentTheme.specialKeyBrush)
                    .clickable { onToggleEmoji() }
                    .size(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Mood,
                    contentDescription = "Emoji mode",
                    tint = if (isEmojiMode) currentTheme.actionKeyTextColor else currentTheme.toolbarIconColor,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Paste button
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(currentTheme.specialKeyBrush)
                    .clickable { onPaste() }
                    .size(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.ContentPaste,
                    contentDescription = "Paste",
                    tint = currentTheme.toolbarIconColor,
                    modifier = Modifier.size(15.dp)
                )
            }
        }

        // Right side quick tools: Cursor Navigation & Dismiss
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            // Move Cursor Left
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(currentTheme.specialKeyBrush)
                    .clickable { onMoveCursor(-1) }
                    .size(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowLeft,
                    contentDescription = "Cursor left",
                    tint = currentTheme.toolbarIconColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Move Cursor Right
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(currentTheme.specialKeyBrush)
                    .clickable { onMoveCursor(1) }
                    .size(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                    contentDescription = "Cursor right",
                    tint = currentTheme.toolbarIconColor,
                    modifier = Modifier.size(18.dp)
                )
            }

            // Hide keyboard
            Box(
                modifier = Modifier
                    .clip(CircleShape)
                    .background(currentTheme.specialKeyBrush)
                    .clickable { onHideKeyboard() }
                    .size(28.dp),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.KeyboardHide,
                    contentDescription = "Hide keyboard",
                    tint = currentTheme.toolbarIconColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

/**
 * Quick Theme Selection Ribbon
 */
@Composable
private fun ThemeSelectorBar(
    currentTheme: GlassTheme,
    onSelectTheme: (KeyboardThemeType) -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 6.dp, vertical = 4.dp)
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        KeyboardThemeType.entries.forEach { themeType ->
            val isSelected = currentTheme.type == themeType
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isSelected) currentTheme.actionKeyBrush else currentTheme.specialKeyBrush)
                    .border(
                        width = if (isSelected) 1.2.dp else 0.6.dp,
                        color = if (isSelected) currentTheme.actionKeyTextColor else currentTheme.keyBorderColor,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .clickable { onSelectTheme(themeType) }
                    .padding(horizontal = 10.dp, vertical = 6.dp)
            ) {
                Text(
                    text = themeType.displayName,
                    color = if (isSelected) currentTheme.actionKeyTextColor else currentTheme.specialKeyTextColor,
                    fontSize = 12.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                )
            }
        }
    }
}

/**
 * Standard iOS-style Alphabet QWERTY Layout
 */
@Composable
private fun LettersKeyboardLayout(
    theme: GlassTheme,
    shiftState: ShiftState,
    actionInfo: ActionKeyInfo,
    showPopupPreview: Boolean,
    doubleSpacePeriod: Boolean,
    onKeyInput: (String) -> Unit,
    onShiftClick: () -> Unit,
    onShiftDoubleTap: () -> Unit,
    onBackspaceClick: () -> Unit,
    onSwitchLayout: (KeyboardLayoutMode) -> Unit,
    onSpaceClick: () -> Unit,
    onSpaceDoubleTap: () -> Unit,
    onPeriodClick: () -> Unit,
    onActionClick: () -> Unit,
    onSwitchIme: () -> Unit
) {
    val row1 = listOf("q", "w", "e", "r", "t", "y", "u", "i", "o", "p")
    val row2 = listOf("a", "s", "d", "f", "g", "h", "j", "k", "l")
    val row3 = listOf("z", "x", "c", "v", "b", "n", "m")

    val isUpper = shiftState.isUppercase()

    Column(modifier = Modifier.fillMaxWidth()) {
        // Row 1: Q W E R T Y U I O P
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            row1.forEach { char ->
                val display = if (isUpper) char.uppercase() else char
                GlassKey(
                    modifier = Modifier.weight(1f),
                    label = display,
                    theme = theme,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_$char",
                    onClick = { onKeyInput(char) }
                )
            }
        }

        // Row 2: A S D F G H J K L (iOS has 0.5 key spacer on each side)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Spacer(modifier = Modifier.weight(0.5f))
            row2.forEach { char ->
                val display = if (isUpper) char.uppercase() else char
                GlassKey(
                    modifier = Modifier.weight(1f),
                    label = display,
                    theme = theme,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_$char",
                    onClick = { onKeyInput(char) }
                )
            }
            Spacer(modifier = Modifier.weight(0.5f))
        }

        // Row 3: Shift, Z X C V B N M, Backspace
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Shift Key (with dynamic icon matching ShiftState)
            GlassKey(
                modifier = Modifier.weight(1.4f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_shift",
                iconContent = {
                    Box(contentAlignment = Alignment.Center) {
                        when (shiftState) {
                            ShiftState.LOWERCASE -> {
                                Icon(
                                    imageVector = Icons.Default.ArrowUpward,
                                    contentDescription = "Shift Lowercase",
                                    tint = theme.specialKeyTextColor.copy(alpha = 0.6f),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            ShiftState.UPPERCASE -> {
                                Icon(
                                    imageVector = Icons.Default.ArrowUpward,
                                    contentDescription = "Shift Uppercase",
                                    tint = theme.keyTextColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            ShiftState.CAPS_LOCK -> {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.ArrowUpward,
                                        contentDescription = "Caps Lock",
                                        tint = if (theme.isDark) Color(0xFF38BDF8) else Color(0xFF007AFF),
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Box(
                                        modifier = Modifier
                                            .width(14.dp)
                                            .height(2.5.dp)
                                            .background(
                                                color = if (theme.isDark) Color(0xFF38BDF8) else Color(0xFF007AFF),
                                                shape = RoundedCornerShape(1.dp)
                                            )
                                    )
                                }
                            }
                        }
                    }
                },
                onClick = onShiftClick,
                onDoubleTap = onShiftDoubleTap
            )

            row3.forEach { char ->
                val display = if (isUpper) char.uppercase() else char
                GlassKey(
                    modifier = Modifier.weight(1f),
                    label = display,
                    theme = theme,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_$char",
                    onClick = { onKeyInput(char) }
                )
            }

            // Backspace Key with Repeat Delete
            GlassKey(
                modifier = Modifier.weight(1.4f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_backspace",
                iconContent = {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Backspace",
                        tint = theme.specialKeyTextColor,
                        modifier = Modifier.size(20.dp)
                    )
                },
                onClick = onBackspaceClick,
                onRepeatClick = onBackspaceClick
            )
        }

        // Row 4: 123, Globe/Switch, Space, Period, Action/Return
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // "123" key
            GlassKey(
                modifier = Modifier.weight(1.3f),
                label = "123",
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                fontSize = 15,
                theme = theme,
                testTag = "key_switch_123",
                onClick = { onSwitchLayout(KeyboardLayoutMode.NUMBERS_SYMBOLS) }
            )

            // Globe / Switch IME key
            GlassKey(
                modifier = Modifier.weight(1.0f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_globe",
                iconContent = {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Switch Input Method",
                        tint = theme.specialKeyTextColor,
                        modifier = Modifier.size(19.dp)
                    )
                },
                onClick = onSwitchIme
            )

            // Spacebar
            GlassKey(
                modifier = Modifier.weight(4.4f),
                label = "space",
                keyStyle = KeyStyle.SPACEBAR,
                fontSize = 14,
                theme = theme,
                testTag = "key_space",
                onClick = onSpaceClick,
                onDoubleTap = onSpaceDoubleTap
            )

            // Period "."
            GlassKey(
                modifier = Modifier.weight(1.0f),
                label = ".",
                theme = theme,
                fontSize = 22,
                testTag = "key_period",
                onClick = onPeriodClick
            )

            // Action / Return key
            GlassKey(
                modifier = Modifier.weight(1.6f),
                label = if (actionInfo.isPrimaryAction) actionInfo.label else "return",
                keyStyle = if (actionInfo.isPrimaryAction) KeyStyle.ACTION_RETURN else KeyStyle.SPECIAL_FUNCTION,
                fontSize = 15,
                theme = theme,
                testTag = "key_action",
                iconContent = if (actionInfo.isPrimaryAction) {
                    {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = actionInfo.label,
                                color = theme.actionKeyTextColor,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                } else null,
                onClick = onActionClick
            )
        }
    }
}

/**
 * Numbers & Primary Symbols Layout (?123)
 */
@Composable
private fun NumbersSymbolsKeyboardLayout(
    theme: GlassTheme,
    actionInfo: ActionKeyInfo,
    showPopupPreview: Boolean,
    onKeyInput: (String) -> Unit,
    onBackspaceClick: () -> Unit,
    onSwitchLayout: (KeyboardLayoutMode) -> Unit,
    onSpaceClick: () -> Unit,
    onActionClick: () -> Unit,
    onSwitchIme: () -> Unit
) {
    val row1 = listOf("1", "2", "3", "4", "5", "6", "7", "8", "9", "0")
    val row2 = listOf("-", "/", ":", ";", "(", ")", "$", "&", "@", "\"")
    val row3 = listOf(".", ",", "?", "!", "'")

    Column(modifier = Modifier.fillMaxWidth()) {
        // Row 1: 1 2 3 4 5 6 7 8 9 0
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            row1.forEach { char ->
                GlassKey(
                    modifier = Modifier.weight(1f),
                    label = char,
                    theme = theme,
                    fontSize = 20,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_num_$char",
                    onClick = { onKeyInput(char) }
                )
            }
        }

        // Row 2: - / : ; ( ) $ & @ "
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            row2.forEach { char ->
                GlassKey(
                    modifier = Modifier.weight(1f),
                    label = char,
                    theme = theme,
                    fontSize = 20,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_sym_$char",
                    onClick = { onKeyInput(char) }
                )
            }
        }

        // Row 3: #+=, . , ? ! ', Backspace
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // #+= switch key
            GlassKey(
                modifier = Modifier.weight(1.5f),
                label = "#+=",
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                fontSize = 14,
                theme = theme,
                testTag = "key_switch_more_symbols",
                onClick = { onSwitchLayout(KeyboardLayoutMode.MORE_SYMBOLS) }
            )

            row3.forEach { char ->
                GlassKey(
                    modifier = Modifier.weight(1.2f),
                    label = char,
                    theme = theme,
                    fontSize = 21,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_sym_$char",
                    onClick = { onKeyInput(char) }
                )
            }

            // Backspace
            GlassKey(
                modifier = Modifier.weight(1.5f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_backspace",
                iconContent = {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Backspace",
                        tint = theme.specialKeyTextColor,
                        modifier = Modifier.size(20.dp)
                    )
                },
                onClick = onBackspaceClick,
                onRepeatClick = onBackspaceClick
            )
        }

        // Row 4: ABC, Globe, Space, ., Return
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassKey(
                modifier = Modifier.weight(1.3f),
                label = "ABC",
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                fontSize = 15,
                theme = theme,
                testTag = "key_switch_abc",
                onClick = { onSwitchLayout(KeyboardLayoutMode.LETTERS) }
            )

            GlassKey(
                modifier = Modifier.weight(1.0f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_globe",
                iconContent = {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Switch Input Method",
                        tint = theme.specialKeyTextColor,
                        modifier = Modifier.size(19.dp)
                    )
                },
                onClick = onSwitchIme
            )

            GlassKey(
                modifier = Modifier.weight(4.4f),
                label = "space",
                keyStyle = KeyStyle.SPACEBAR,
                fontSize = 14,
                theme = theme,
                testTag = "key_space",
                onClick = onSpaceClick
            )

            GlassKey(
                modifier = Modifier.weight(1.0f),
                label = ".",
                theme = theme,
                fontSize = 22,
                testTag = "key_period",
                onClick = { onKeyInput(".") }
            )

            GlassKey(
                modifier = Modifier.weight(1.6f),
                label = if (actionInfo.isPrimaryAction) actionInfo.label else "return",
                keyStyle = if (actionInfo.isPrimaryAction) KeyStyle.ACTION_RETURN else KeyStyle.SPECIAL_FUNCTION,
                fontSize = 15,
                theme = theme,
                testTag = "key_action",
                onClick = onActionClick
            )
        }
    }
}

/**
 * Secondary Symbols Layout (#+=)
 */
@Composable
private fun MoreSymbolsKeyboardLayout(
    theme: GlassTheme,
    actionInfo: ActionKeyInfo,
    showPopupPreview: Boolean,
    onKeyInput: (String) -> Unit,
    onBackspaceClick: () -> Unit,
    onSwitchLayout: (KeyboardLayoutMode) -> Unit,
    onSpaceClick: () -> Unit,
    onActionClick: () -> Unit,
    onSwitchIme: () -> Unit
) {
    val row1 = listOf("[", "]", "{", "}", "#", "%", "^", "*", "+", "=")
    val row2 = listOf("_", "\\", "|", "~", "<", ">", "€", "£", "¥", "•")
    val row3 = listOf(".", ",", "?", "!", "'")

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            row1.forEach { char ->
                GlassKey(
                    modifier = Modifier.weight(1f),
                    label = char,
                    theme = theme,
                    fontSize = 20,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_moresym_$char",
                    onClick = { onKeyInput(char) }
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            row2.forEach { char ->
                GlassKey(
                    modifier = Modifier.weight(1f),
                    label = char,
                    theme = theme,
                    fontSize = 20,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_moresym_$char",
                    onClick = { onKeyInput(char) }
                )
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassKey(
                modifier = Modifier.weight(1.5f),
                label = "123",
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                fontSize = 14,
                theme = theme,
                testTag = "key_switch_123",
                onClick = { onSwitchLayout(KeyboardLayoutMode.NUMBERS_SYMBOLS) }
            )

            row3.forEach { char ->
                GlassKey(
                    modifier = Modifier.weight(1.2f),
                    label = char,
                    theme = theme,
                    fontSize = 21,
                    showPopupPreview = showPopupPreview,
                    testTag = "key_sym_$char",
                    onClick = { onKeyInput(char) }
                )
            }

            GlassKey(
                modifier = Modifier.weight(1.5f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_backspace",
                iconContent = {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Backspace",
                        tint = theme.specialKeyTextColor,
                        modifier = Modifier.size(20.dp)
                    )
                },
                onClick = onBackspaceClick,
                onRepeatClick = onBackspaceClick
            )
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassKey(
                modifier = Modifier.weight(1.3f),
                label = "ABC",
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                fontSize = 15,
                theme = theme,
                testTag = "key_switch_abc",
                onClick = { onSwitchLayout(KeyboardLayoutMode.LETTERS) }
            )

            GlassKey(
                modifier = Modifier.weight(1.0f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_globe",
                iconContent = {
                    Icon(
                        imageVector = Icons.Default.Language,
                        contentDescription = "Switch Input Method",
                        tint = theme.specialKeyTextColor,
                        modifier = Modifier.size(19.dp)
                    )
                },
                onClick = onSwitchIme
            )

            GlassKey(
                modifier = Modifier.weight(4.4f),
                label = "space",
                keyStyle = KeyStyle.SPACEBAR,
                fontSize = 14,
                theme = theme,
                testTag = "key_space",
                onClick = onSpaceClick
            )

            GlassKey(
                modifier = Modifier.weight(1.0f),
                label = ".",
                theme = theme,
                fontSize = 22,
                testTag = "key_period",
                onClick = { onKeyInput(".") }
            )

            GlassKey(
                modifier = Modifier.weight(1.6f),
                label = if (actionInfo.isPrimaryAction) actionInfo.label else "return",
                keyStyle = if (actionInfo.isPrimaryAction) KeyStyle.ACTION_RETURN else KeyStyle.SPECIAL_FUNCTION,
                fontSize = 15,
                theme = theme,
                testTag = "key_action",
                onClick = onActionClick
            )
        }
    }
}

/**
 * iOS-style Emoji Palette View
 */
@Composable
private fun EmojiKeyboardLayout(
    theme: GlassTheme,
    selectedCategoryIndex: Int,
    onSelectCategory: (Int) -> Unit,
    onEmojiClick: (String) -> Unit,
    onBackspaceClick: () -> Unit,
    onReturnToLetters: () -> Unit,
    onSpaceClick: () -> Unit
) {
    val categories = EmojiData.categories
    val currentCategory = categories.getOrElse(selectedCategoryIndex) { categories.first() }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .height(220.dp)
    ) {
        // Emoji Category selector tab bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(36.dp)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            categories.forEachIndexed { index, category ->
                val isSelected = index == selectedCategoryIndex
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(if (isSelected) theme.actionKeyBrush else theme.specialKeyBrush)
                        .border(
                            width = 0.5.dp,
                            color = if (isSelected) theme.actionKeyTextColor else theme.keyBorderColor,
                            shape = RoundedCornerShape(8.dp)
                        )
                        .clickable { onSelectCategory(index) }
                        .padding(horizontal = 10.dp, vertical = 4.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "${category.icon} ${category.name}",
                        color = if (isSelected) theme.actionKeyTextColor else theme.specialKeyTextColor,
                        fontSize = 12.sp,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                    )
                }
            }
        }

        // Emoji Grid
        LazyVerticalGrid(
            columns = GridCells.Fixed(8),
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 4.dp, vertical = 2.dp)
        ) {
            items(currentCategory.emojis) { emoji ->
                Box(
                    modifier = Modifier
                        .padding(2.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .clickable { onEmojiClick(emoji) }
                        .padding(vertical = 6.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = emoji,
                        fontSize = 24.sp
                    )
                }
            }
        }

        // Bottom Navigation bar in emoji mode
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .padding(horizontal = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            GlassKey(
                modifier = Modifier.weight(1.5f),
                label = "ABC",
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                fontSize = 15,
                theme = theme,
                testTag = "key_emoji_abc",
                onClick = onReturnToLetters
            )

            GlassKey(
                modifier = Modifier.weight(5f),
                label = "space",
                keyStyle = KeyStyle.SPACEBAR,
                fontSize = 14,
                theme = theme,
                testTag = "key_emoji_space",
                onClick = onSpaceClick
            )

            GlassKey(
                modifier = Modifier.weight(1.5f),
                keyStyle = KeyStyle.SPECIAL_FUNCTION,
                theme = theme,
                testTag = "key_emoji_backspace",
                iconContent = {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Backspace,
                        contentDescription = "Backspace",
                        tint = theme.specialKeyTextColor,
                        modifier = Modifier.size(20.dp)
                    )
                },
                onClick = onBackspaceClick,
                onRepeatClick = onBackspaceClick
            )
        }
    }
}
