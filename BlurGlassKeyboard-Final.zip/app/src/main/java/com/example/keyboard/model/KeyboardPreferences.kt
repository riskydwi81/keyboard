package com.example.keyboard.model

import android.content.Context
import android.content.SharedPreferences

class KeyboardPreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    var themeType: KeyboardThemeType
        get() {
            val name = prefs.getString(KEY_THEME, KeyboardThemeType.MIDNIGHT_OBSIDIAN.name)
            return try {
                KeyboardThemeType.valueOf(name ?: KeyboardThemeType.MIDNIGHT_OBSIDIAN.name)
            } catch (e: Exception) {
                KeyboardThemeType.MIDNIGHT_OBSIDIAN
            }
        }
        set(value) {
            prefs.edit().putString(KEY_THEME, value.name).apply()
        }

    var hapticFeedback: Boolean
        get() = prefs.getBoolean(KEY_HAPTIC, true)
        set(value) = prefs.edit().putBoolean(KEY_HAPTIC, value).apply()

    var hapticStrength: Int // 1 (Soft), 2 (Medium), 3 (Firm)
        get() = prefs.getInt(KEY_HAPTIC_STRENGTH, 2)
        set(value) = prefs.edit().putInt(KEY_HAPTIC_STRENGTH, value).apply()

    var soundFeedback: Boolean
        get() = prefs.getBoolean(KEY_SOUND, true)
        set(value) = prefs.edit().putBoolean(KEY_SOUND, value).apply()

    var keyPopupPreview: Boolean
        get() = prefs.getBoolean(KEY_KEY_POPUP, true)
        set(value) = prefs.edit().putBoolean(KEY_KEY_POPUP, value).apply()

    var doubleSpacePeriod: Boolean
        get() = prefs.getBoolean(KEY_DOUBLE_SPACE_PERIOD, true)
        set(value) = prefs.edit().putBoolean(KEY_DOUBLE_SPACE_PERIOD, value).apply()

    var autoCapitalize: Boolean
        get() = prefs.getBoolean(KEY_AUTO_CAPITALIZE, true)
        set(value) = prefs.edit().putBoolean(KEY_AUTO_CAPITALIZE, value).apply()

    companion object {
        private const val PREFS_NAME = "blurglass_keyboard_preferences"
        private const val KEY_THEME = "keyboard_theme"
        private const val KEY_HAPTIC = "haptic_feedback"
        private const val KEY_HAPTIC_STRENGTH = "haptic_strength"
        private const val KEY_SOUND = "sound_feedback"
        private const val KEY_KEY_POPUP = "key_popup_preview"
        private const val KEY_DOUBLE_SPACE_PERIOD = "double_space_period"
        private const val KEY_AUTO_CAPITALIZE = "auto_capitalize"
    }
}
