package com.example.keyboard.model

import android.view.inputmethod.EditorInfo

enum class KeyboardLayoutMode {
    LETTERS,
    NUMBERS_SYMBOLS,
    MORE_SYMBOLS,
    EMOJI
}

enum class ShiftState {
    LOWERCASE,
    UPPERCASE,
    CAPS_LOCK;

    fun isUppercase(): Boolean = this != LOWERCASE
}

data class ActionKeyInfo(
    val actionId: Int,
    val label: String,
    val isPrimaryAction: Boolean
) {
    companion object {
        fun fromEditorInfo(editorInfo: EditorInfo?): ActionKeyInfo {
            if (editorInfo == null) {
                return ActionKeyInfo(EditorInfo.IME_ACTION_NONE, "return", false)
            }
            val imeOptions = editorInfo.imeOptions
            val action = imeOptions and EditorInfo.IME_MASK_ACTION
            val isNoEnterAction = (imeOptions and EditorInfo.IME_FLAG_NO_ENTER_ACTION) != 0

            if (isNoEnterAction) {
                return ActionKeyInfo(EditorInfo.IME_ACTION_NONE, "return", false)
            }

            return when (action) {
                EditorInfo.IME_ACTION_GO -> ActionKeyInfo(action, "Go", true)
                EditorInfo.IME_ACTION_SEARCH -> ActionKeyInfo(action, "Search", true)
                EditorInfo.IME_ACTION_SEND -> ActionKeyInfo(action, "Send", true)
                EditorInfo.IME_ACTION_NEXT -> ActionKeyInfo(action, "Next", true)
                EditorInfo.IME_ACTION_DONE -> ActionKeyInfo(action, "Done", true)
                EditorInfo.IME_ACTION_PREVIOUS -> ActionKeyInfo(action, "Prev", true)
                else -> ActionKeyInfo(EditorInfo.IME_ACTION_NONE, "return", false)
            }
        }
    }
}
