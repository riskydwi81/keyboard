package com.example.keyboard.ui

import android.os.SystemClock
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import com.example.keyboard.model.GlassTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

enum class KeyStyle {
    STANDARD_LETTER,
    SPECIAL_FUNCTION,
    ACTION_RETURN,
    SPACEBAR
}

@Composable
fun GlassKey(
    modifier: Modifier = Modifier,
    label: String? = null,
    subLabel: String? = null,
    icon: ImageVector? = null,
    iconContent: (@Composable () -> Unit)? = null,
    keyStyle: KeyStyle = KeyStyle.STANDARD_LETTER,
    theme: GlassTheme,
    showPopupPreview: Boolean = true,
    fontSize: Int = 22,
    testTag: String = "keyboard_key",
    onPressStart: () -> Unit = {},
    onPressEnd: () -> Unit = {},
    onClick: () -> Unit = {},
    onLongPress: (() -> Unit)? = null,
    onRepeatClick: (() -> Unit)? = null,
    onDoubleTap: (() -> Unit)? = null
) {
    var isPressed by remember { mutableStateOf(false) }
    var lastTapTime by remember { mutableStateOf(0L) }
    val coroutineScope = rememberCoroutineScope()

    // Smooth press scale animation
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.94f else 1.0f,
        animationSpec = tween(durationMillis = 60),
        label = "key_scale"
    )

    // Repeat timer for keys like backspace
    LaunchedEffect(isPressed) {
        if (isPressed && onRepeatClick != null) {
            delay(400) // Initial hold delay before repeat
            while (isActive && isPressed) {
                onRepeatClick()
                delay(50) // Repeat interval
            }
        }
    }

    val brush = when (keyStyle) {
        KeyStyle.STANDARD_LETTER -> if (isPressed) theme.keyPressedBrush else theme.keyBrush
        KeyStyle.SPECIAL_FUNCTION -> if (isPressed) theme.specialKeyPressedBrush else theme.specialKeyBrush
        KeyStyle.ACTION_RETURN -> if (isPressed) theme.actionKeyPressedBrush else theme.actionKeyBrush
        KeyStyle.SPACEBAR -> if (isPressed) theme.keyPressedBrush else theme.keyBrush
    }

    val textColor = when (keyStyle) {
        KeyStyle.STANDARD_LETTER -> theme.keyTextColor
        KeyStyle.SPECIAL_FUNCTION -> theme.specialKeyTextColor
        KeyStyle.ACTION_RETURN -> theme.actionKeyTextColor
        KeyStyle.SPACEBAR -> theme.keyTextColor.copy(alpha = 0.7f)
    }

    val cornerRadius = when (keyStyle) {
        KeyStyle.SPACEBAR -> 8.dp
        else -> 6.dp
    }
    val shape = RoundedCornerShape(cornerRadius)

    Box(
        modifier = modifier
            .testTag(testTag)
            .padding(horizontal = 3.dp, vertical = 5.dp)
            .scale(scale)
            .zIndex(if (isPressed && showPopupPreview && keyStyle == KeyStyle.STANDARD_LETTER) 10f else 1f)
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        isPressed = true
                        onPressStart()
                        val success = tryAwaitRelease()
                        isPressed = false
                        onPressEnd()
                        if (success) {
                            val now = SystemClock.uptimeMillis()
                            if (now - lastTapTime < 300L && onDoubleTap != null) {
                                onDoubleTap()
                                lastTapTime = 0L
                            } else {
                                lastTapTime = now
                                onClick()
                            }
                        }
                    },
                    onLongPress = {
                        if (onLongPress != null) {
                            onLongPress()
                        }
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        // iOS Glass Keycap Shadow & Body
        Box(
            modifier = Modifier
                .fillMaxSize()
                .shadow(
                    elevation = if (isPressed) 0.5.dp else 2.dp,
                    shape = shape,
                    clip = false
                )
                .background(brush = brush, shape = shape)
                .border(
                    width = 0.8.dp,
                    color = theme.keyBorderColor,
                    shape = shape
                )
                .drawWithContent {
                    drawContent()
                    // Specular Top Highlight line for physical glass refraction look
                    val highlightHeight = 1.2.dp.toPx()
                    drawLine(
                        color = theme.keyTopHighlightColor,
                        start = Offset(4f, highlightHeight),
                        end = Offset(size.width - 4f, highlightHeight),
                        strokeWidth = highlightHeight
                    )
                },
            contentAlignment = Alignment.Center
        ) {
            if (iconContent != null) {
                iconContent()
            } else if (label != null) {
                Text(
                    text = label,
                    color = textColor,
                    fontSize = fontSize.sp,
                    fontWeight = if (keyStyle == KeyStyle.ACTION_RETURN || keyStyle == KeyStyle.SPECIAL_FUNCTION)
                        FontWeight.SemiBold else FontWeight.Normal,
                    fontFamily = FontFamily.SansSerif,
                    textAlign = TextAlign.Center
                )
            }

            if (subLabel != null) {
                Text(
                    text = subLabel,
                    color = textColor.copy(alpha = 0.45f),
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 2.dp, end = 4.dp)
                )
            }
        }

        // iOS Style Popout Magnifier Bubble (when key is pressed down)
        if (isPressed && showPopupPreview && keyStyle == KeyStyle.STANDARD_LETTER && label != null && label.length == 1) {
            KeyPopoutBubble(
                label = label,
                theme = theme
            )
        }
    }
}

/**
 * iOS-style glass magnifier bubble shown above the pressed key
 */
@Composable
private fun BoxScope.KeyPopoutBubble(
    label: String,
    theme: GlassTheme
) {
    val bubbleShape = RoundedCornerShape(10.dp)

    Box(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .offset(y = (-52).dp)
            .size(width = 54.dp, height = 52.dp)
            .shadow(elevation = 6.dp, shape = bubbleShape)
            .background(color = theme.popupBubbleBg, shape = bubbleShape)
            .border(width = 1.dp, color = theme.keyTopHighlightColor, shape = bubbleShape),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = theme.popupTextColor,
            fontSize = 30.sp,
            fontWeight = FontWeight.Normal,
            fontFamily = FontFamily.SansSerif
        )
    }
}
