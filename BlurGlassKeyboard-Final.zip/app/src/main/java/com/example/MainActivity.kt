package com.example

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.inputmethod.InputMethodManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ColorLens
import androidx.compose.material.icons.filled.Keyboard
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TouchApp
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.Vibration
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.keyboard.model.GlassThemes
import com.example.keyboard.model.KeyboardPreferences
import com.example.keyboard.model.KeyboardThemeType
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainSetupScreen()
            }
        }
    }
}

@Composable
fun MainSetupScreen() {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val preferences = remember { KeyboardPreferences(context) }

    var isEnabled by remember { mutableStateOf(checkIsImeEnabled(context)) }
    var isSelected by remember { mutableStateOf(checkIsImeSelected(context)) }

    // Settings state
    var selectedThemeType by remember { mutableStateOf(preferences.themeType) }
    var hapticFeedback by remember { mutableStateOf(preferences.hapticFeedback) }
    var hapticStrength by remember { mutableIntStateOf(preferences.hapticStrength) }
    var soundFeedback by remember { mutableStateOf(preferences.soundFeedback) }
    var keyPopupPreview by remember { mutableStateOf(preferences.keyPopupPreview) }
    var doubleSpacePeriod by remember { mutableStateOf(preferences.doubleSpacePeriod) }
    var autoCapitalize by remember { mutableStateOf(preferences.autoCapitalize) }

    // Test text state
    var testText by remember { mutableStateOf("") }

    // Refresh IME status on activity resume
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) {
                isEnabled = checkIsImeEnabled(context)
                isSelected = checkIsImeSelected(context)
            }
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose {
            lifecycleOwner.lifecycle.removeObserver(observer)
        }
    }

    val currentTheme = GlassThemes.getTheme(selectedThemeType)

    // Background styling
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF0F172A),
                        Color(0xFF1E1B4B),
                        Color(0xFF090D16)
                    )
                )
            )
    ) {
        // Ambient glass specular circles
        Box(
            modifier = Modifier
                .size(280.dp)
                .align(Alignment.TopEnd)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0x3338BDF8),
                                Color(0x0038BDF8)
                            )
                        )
                    )
                }
        )

        Box(
            modifier = Modifier
                .size(320.dp)
                .align(Alignment.BottomStart)
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(
                                Color(0x2B818CF8),
                                Color(0x00818CF8)
                            )
                        )
                    )
                }
        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentPadding = PaddingValues(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            // Header
            item {
                HeaderSection()
            }

            // Keyboard Activation Steps
            item {
                ActivationStepsSection(
                    isEnabled = isEnabled,
                    isSelected = isSelected,
                    onEnableClick = {
                        val intent = Intent(Settings.ACTION_INPUT_METHOD_SETTINGS)
                        context.startActivity(intent)
                    },
                    onSelectClick = {
                        val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager
                        imm?.showInputMethodPicker()
                    }
                )
            }

            // Interactive Live Test Arena
            item {
                InteractiveTestCard(
                    testText = testText,
                    onTextChange = { testText = it },
                    themeType = selectedThemeType
                )
            }

            // Theme Customization Card
            item {
                ThemeSelectionCard(
                    selectedTheme = selectedThemeType,
                    onThemeSelected = { newTheme ->
                        selectedThemeType = newTheme
                        preferences.themeType = newTheme
                    }
                )
            }

            // Keyboard Preferences Card
            item {
                PreferencesCard(
                    hapticFeedback = hapticFeedback,
                    onHapticChange = {
                        hapticFeedback = it
                        preferences.hapticFeedback = it
                    },
                    hapticStrength = hapticStrength,
                    onHapticStrengthChange = {
                        hapticStrength = it
                        preferences.hapticStrength = it
                    },
                    soundFeedback = soundFeedback,
                    onSoundChange = {
                        soundFeedback = it
                        preferences.soundFeedback = it
                    },
                    keyPopupPreview = keyPopupPreview,
                    onKeyPopupChange = {
                        keyPopupPreview = it
                        preferences.keyPopupPreview = it
                    },
                    doubleSpacePeriod = doubleSpacePeriod,
                    onDoubleSpaceChange = {
                        doubleSpacePeriod = it
                        preferences.doubleSpacePeriod = it
                    },
                    autoCapitalize = autoCapitalize,
                    onAutoCapitalizeChange = {
                        autoCapitalize = it
                        preferences.autoCapitalize = it
                    }
                )
            }

            // Gestures & Tips Card
            item {
                TipsCard()
            }

            // Footer padding
            item {
                Spacer(modifier = Modifier.height(16.dp))
            }
        }
    }
}

@Composable
private fun HeaderSection() {
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Frosted Glass Icon Badge
        Box(
            modifier = Modifier
                .size(68.dp)
                .shadow(12.dp, RoundedCornerShape(20.dp))
                .background(
                    brush = Brush.linearGradient(
                        colors = listOf(
                            Color(0x4DFFFFFF),
                            Color(0x1AFFFFFF)
                        )
                    ),
                    shape = RoundedCornerShape(20.dp)
                )
                .border(
                    width = 1.2.dp,
                    color = Color(0x66FFFFFF),
                    shape = RoundedCornerShape(20.dp)
                ),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = Icons.Default.Keyboard,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(36.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = stringResource(R.string.app_name),
            color = Color.White,
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = 0.5.sp
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = "Modern iOS-Inspired Frosted Glassmorphism Keyboard",
            color = Color(0xFF94A3B8),
            fontSize = 13.sp,
            fontWeight = FontWeight.Normal
        )
    }
}

@Composable
private fun ActivationStepsSection(
    isEnabled: Boolean,
    isSelected: Boolean,
    onEnableClick: () -> Unit,
    onSelectClick: () -> Unit
) {
    val isFullyActive = isEnabled && isSelected

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        if (isFullyActive) {
            // Success Active Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(
                        brush = Brush.horizontalGradient(
                            listOf(Color(0x2E10B981), Color(0x1A059669))
                        )
                    )
                    .border(1.dp, Color(0x6610B981), RoundedCornerShape(16.dp))
                    .padding(16.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Active",
                        tint = Color(0xFF34D399),
                        modifier = Modifier.size(28.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "BlurGlass Keyboard is Active!",
                            color = Color(0xFFECFDF5),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "Ready to type anywhere across Android apps.",
                            color = Color(0xFFA7F3D0),
                            fontSize = 12.sp
                        )
                    }
                }
            }
        }

        // Step 1: Enable in Settings Card
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StepNumberBadge(number = "1", isComplete = isEnabled)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Enable in System Settings",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isEnabled) "Enabled in Input Methods" else "Enable toggle in Android settings",
                            color = if (isEnabled) Color(0xFF34D399) else Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    }
                }

                Button(
                    onClick = onEnableClick,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isEnabled) Color(0x2B10B981) else Color(0xFF007AFF),
                        contentColor = if (isEnabled) Color(0xFF34D399) else Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("enable_keyboard_button")
                ) {
                    Text(
                        text = if (isEnabled) "Enabled ✓" else "Enable",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }

        // Step 2: Select Default Input Method Card
        GlassCard(
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StepNumberBadge(number = "2", isComplete = isSelected)
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "Select BlurGlass Keyboard",
                            color = Color.White,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = if (isSelected) "Currently Active Default" else "Switch to BlurGlass in picker",
                            color = if (isSelected) Color(0xFF34D399) else Color(0xFF94A3B8),
                            fontSize = 12.sp
                        )
                    }
                }

                Button(
                    onClick = onSelectClick,
                    enabled = isEnabled,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isSelected) Color(0x2B10B981) else Color(0xFF007AFF),
                        contentColor = if (isSelected) Color(0xFF34D399) else Color.White
                    ),
                    shape = RoundedCornerShape(10.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                    modifier = Modifier.testTag("select_keyboard_button")
                ) {
                    Text(
                        text = if (isSelected) "Active ✓" else "Select",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun StepNumberBadge(
    number: String,
    isComplete: Boolean
) {
    Box(
        modifier = Modifier
            .size(32.dp)
            .background(
                color = if (isComplete) Color(0xFF10B981) else Color(0x26FFFFFF),
                shape = CircleShape
            )
            .border(
                width = 1.dp,
                color = if (isComplete) Color(0xFF34D399) else Color(0x40FFFFFF),
                shape = CircleShape
            ),
        contentAlignment = Alignment.Center
    ) {
        if (isComplete) {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp)
            )
        } else {
            Text(
                text = number,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
private fun InteractiveTestCard(
    testText: String,
    onTextChange: (String) -> Unit,
    themeType: KeyboardThemeType
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Default.TouchApp,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Live Keyboard Test Ground",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = "Tap the input field below to invoke and test your frosted glass keyboard immediately:",
                color = Color(0xFF94A3B8),
                fontSize = 12.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = testText,
                onValueChange = onTextChange,
                placeholder = {
                    Text(
                        text = "Tap here to try typing with BlurGlass…",
                        color = Color(0xFF64748B),
                        fontSize = 14.sp
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("test_typing_input"),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Color(0xFF007AFF),
                    unfocusedBorderColor = Color(0x33FFFFFF),
                    focusedContainerColor = Color(0x1FFFFFFF),
                    unfocusedContainerColor = Color(0x14FFFFFF),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    cursorColor = Color(0xFF38BDF8)
                ),
                minLines = 2,
                maxLines = 4
            )

            if (testText.isNotEmpty()) {
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Text(
                        text = "Clear text",
                        color = Color(0xFF38BDF8),
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clickable { onTextChange("") }
                            .padding(4.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ThemeSelectionCard(
    selectedTheme: KeyboardThemeType,
    onThemeSelected: (KeyboardThemeType) -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.ColorLens,
                    contentDescription = null,
                    tint = Color(0xFFF472B6),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Glassmorphism Themes",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                KeyboardThemeType.entries.forEach { themeType ->
                    val isCurrent = selectedTheme == themeType
                    val theme = GlassThemes.getTheme(themeType)

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(
                                brush = if (isCurrent) {
                                    Brush.horizontalGradient(
                                        listOf(Color(0x33007AFF), Color(0x1A007AFF))
                                    )
                                } else {
                                    Brush.horizontalGradient(
                                        listOf(Color(0x14FFFFFF), Color(0x08FFFFFF))
                                    )
                                }
                            )
                            .border(
                                width = if (isCurrent) 1.2.dp else 0.5.dp,
                                color = if (isCurrent) Color(0xFF007AFF) else Color(0x26FFFFFF),
                                shape = RoundedCornerShape(12.dp)
                            )
                            .clickable { onThemeSelected(themeType) }
                            .padding(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Theme preview mini-pill
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(theme.backgroundBrush)
                                        .border(0.8.dp, theme.keyBorderColor, RoundedCornerShape(8.dp)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = "A",
                                        color = theme.keyTextColor,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Spacer(modifier = Modifier.width(12.dp))

                                Column {
                                    Text(
                                        text = themeType.displayName,
                                        color = Color.White,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    Text(
                                        text = themeType.description,
                                        color = Color(0xFF94A3B8),
                                        fontSize = 11.sp
                                    )
                                }
                            }

                            if (isCurrent) {
                                Icon(
                                    imageVector = Icons.Default.CheckCircle,
                                    contentDescription = "Selected",
                                    tint = Color(0xFF007AFF),
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun PreferencesCard(
    hapticFeedback: Boolean,
    onHapticChange: (Boolean) -> Unit,
    hapticStrength: Int,
    onHapticStrengthChange: (Int) -> Unit,
    soundFeedback: Boolean,
    onSoundChange: (Boolean) -> Unit,
    keyPopupPreview: Boolean,
    onKeyPopupChange: (Boolean) -> Unit,
    doubleSpacePeriod: Boolean,
    onDoubleSpaceChange: (Boolean) -> Unit,
    autoCapitalize: Boolean,
    onAutoCapitalizeChange: (Boolean) -> Unit
) {
    GlassCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Tune,
                    contentDescription = null,
                    tint = Color(0xFF38BDF8),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Typing Preferences",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Haptic Feedback Switch
            SettingRowWithSwitch(
                title = "Haptic Vibration Feedback",
                subtitle = "Subtle iOS-like vibration click on keypress",
                icon = Icons.Default.Vibration,
                checked = hapticFeedback,
                onCheckedChange = onHapticChange
            )

            // Haptic Strength Slider
            if (hapticFeedback) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(start = 32.dp, end = 8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Vibration Intensity",
                            color = Color(0xFFCBD5E1),
                            fontSize = 12.sp
                        )
                        Text(
                            text = when (hapticStrength) {
                                1 -> "Soft (iOS Tap)"
                                2 -> "Medium (Crisp)"
                                3 -> "Firm"
                                else -> "Medium"
                            },
                            color = Color(0xFF38BDF8),
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    Slider(
                        value = hapticStrength.toFloat(),
                        onValueChange = { onHapticStrengthChange(it.toInt()) },
                        valueRange = 1f..3f,
                        steps = 1,
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFF007AFF),
                            activeTrackColor = Color(0xFF007AFF),
                            inactiveTrackColor = Color(0x33FFFFFF)
                        )
                    )
                }
            }

            // Sound Feedback Switch
            SettingRowWithSwitch(
                title = "Keypress Sound Effects",
                subtitle = "Subtle mechanical click audio",
                icon = Icons.Default.VolumeUp,
                checked = soundFeedback,
                onCheckedChange = onSoundChange
            )

            // Key Popup Preview Bubble Switch
            SettingRowWithSwitch(
                title = "Key Popup Magnifier",
                subtitle = "Enlarge letter bubble preview above finger when touched",
                icon = Icons.Default.TouchApp,
                checked = keyPopupPreview,
                onCheckedChange = onKeyPopupChange
            )

            // Double Space Period Switch
            SettingRowWithSwitch(
                title = "Double-Tap Space for Period",
                subtitle = "Double tap spacebar to quickly insert a period and space",
                icon = Icons.Default.Keyboard,
                checked = doubleSpacePeriod,
                onCheckedChange = onDoubleSpaceChange
            )

            // Auto-Capitalization Switch
            SettingRowWithSwitch(
                title = "Auto-Capitalization",
                subtitle = "Capitalize first word of each sentence automatically",
                icon = Icons.Default.Settings,
                checked = autoCapitalize,
                onCheckedChange = onAutoCapitalizeChange
            )
        }
    }
}

@Composable
private fun SettingRowWithSwitch(
    title: String,
    subtitle: String,
    icon: ImageVector,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = Color(0xFF94A3B8),
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = subtitle,
                    color = Color(0xFF94A3B8),
                    fontSize = 11.sp
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = Color(0xFF007AFF),
                uncheckedThumbColor = Color(0xFF94A3B8),
                uncheckedTrackColor = Color(0x33FFFFFF)
            )
        )
    }
}

@Composable
private fun TipsCard() {
    GlassCard(
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Lightbulb,
                    contentDescription = null,
                    tint = Color(0xFFFBBF24),
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Pro Keyboard Shortcuts",
                    color = Color.White,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            TipItem(
                badge = "CAPS",
                title = "Double Tap Shift",
                desc = "Quickly double tap the Shift key to lock uppercase typing (Caps Lock)."
            )

            TipItem(
                badge = ". ",
                title = "Double Tap Space",
                desc = "Double tap the spacebar to automatically insert a period and space."
            )

            TipItem(
                badge = "⇄",
                title = "Precision Cursor Navigation",
                desc = "Use the left and right arrow buttons on the frosted top toolbar for exact cursor placement."
            )

            TipItem(
                badge = "📋",
                title = "1-Tap Clipboard Paste",
                desc = "Tap the paste icon on the top glass toolbar to instantly paste copied text."
            )

            TipItem(
                badge = "🌐",
                title = "Globe Key",
                desc = "Tap the globe key to seamlessly switch between other installed keyboards."
            )
        }
    }
}

@Composable
private fun TipItem(
    badge: String,
    title: String,
    desc: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            modifier = Modifier
                .size(width = 34.dp, height = 24.dp)
                .background(Color(0x26FFFFFF), RoundedCornerShape(6.dp))
                .border(0.5.dp, Color(0x40FFFFFF), RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = badge,
                color = Color(0xFF38BDF8),
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold
            )
        }

        Spacer(modifier = Modifier.width(10.dp))

        Column {
            Text(
                text = title,
                color = Color.White,
                fontSize = 13.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = desc,
                color = Color(0xFF94A3B8),
                fontSize = 11.sp
            )
        }
    }
}

/**
 * Reusable Glassmorphism Card with subtle frosted gradient, specular border, and elevation
 */
@Composable
private fun GlassCard(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        modifier = modifier
            .shadow(
                elevation = 8.dp,
                shape = shape,
                clip = false
            )
            .background(
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x2BFFFFFF),
                        Color(0x14FFFFFF)
                    )
                ),
                shape = shape
            )
            .border(
                width = 1.dp,
                brush = Brush.verticalGradient(
                    colors = listOf(
                        Color(0x55FFFFFF),
                        Color(0x1AFFFFFF)
                    )
                ),
                shape = shape
            )
    ) {
        content()
    }
}

private fun checkIsImeEnabled(context: Context): Boolean {
    val imm = context.getSystemService(Context.INPUT_METHOD_SERVICE) as? InputMethodManager ?: return false
    val enabledMethods = imm.enabledInputMethodList
    val packageName = context.packageName
    return enabledMethods.any { it.packageName == packageName }
}

private fun checkIsImeSelected(context: Context): Boolean {
    val currentIme = Settings.Secure.getString(
        context.contentResolver,
        Settings.Secure.DEFAULT_INPUT_METHOD
    ) ?: ""
    return currentIme.contains(context.packageName)
}
