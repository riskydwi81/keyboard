package com.riskydwi81.blurkeyboard

import android.graphics.Color
import android.graphics.RenderEffect
import android.graphics.Shader
import android.os.Build
import android.inputmethodservice.InputMethodService
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputConnection
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.drawable.GradientDrawable
import android.content.res.ColorStateList
import android.view.HapticFeedbackConstants

class BlurKeyboardService : InputMethodService() {

    private val rows = listOf(
        listOf("q","w","e","r","t","y","u","i","o","p"),
        listOf("a","s","d","f","g","h","j","k","l"),
        listOf("z","x","c","v","b","n","m","⌫")
    )

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(6, 8, 6, 8)
            setBackgroundColor(Color.argb(210, 28, 28, 30))
            if (Build.VERSION.SDK_INT >= 31) {
                setRenderEffect(RenderEffect.createBlurEffect(0f, 0f, Shader.TileMode.CLAMP))
            }
        }

        rows.forEachIndexed { index, row ->
            val line = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER
            }

            row.forEach { key ->
                val weight = if (index == 1 && key == "l") 0.92f else 1f
                line.addView(keyView(key), LinearLayout.LayoutParams(0, 52.dp(), weight).apply {
                    setMargins(3, 3, 3, 3)
                })
            }
            root.addView(line, LinearLayout.LayoutParams(-1, 58.dp()))
        }

        val bottom = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
        }

        bottom.addView(keyView("123"), lp(0.9f))
        bottom.addView(keyView(","), lp(0.75f))
        bottom.addView(keyView("space"), lp(4.6f))
        bottom.addView(keyView("."), lp(0.75f))
        bottom.addView(keyView("↵"), lp(1.0f))
        root.addView(bottom, LinearLayout.LayoutParams(-1, 58.dp()))

        return root
    }

    private fun lp(weight: Float) = LinearLayout.LayoutParams(0, 52.dp(), weight).apply {
        setMargins(3, 3, 3, 3)
    }

    private fun keyView(label: String): TextView {
        return TextView(this).apply {
            text = if (label == "space") "" else label
            textSize = if (label == "space") 14f else 18f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.RECTANGLE
                cornerRadius = 11.dp().toFloat()
                setColor(Color.argb(105, 255, 255, 255))
                setStroke(1.dp(), Color.argb(55, 255, 255, 255))
            }
            isAllCaps = false
            setOnClickListener {
                performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                val ic = currentInputConnection ?: return@setOnClickListener
                when (label) {
                    "⌫" -> ic.deleteSurroundingText(1, 0)
                    "space" -> ic.commitText(" ", 1)
                    "↵" -> ic.sendKeyEvent(android.view.KeyEvent(android.view.KeyEvent.ACTION_DOWN, android.view.KeyEvent.KEYCODE_ENTER))
                    "123" -> {}
                    else -> ic.commitText(label, 1)
                }
            }
        }
    }

    private fun Int.dp(): Int = (this * resources.displayMetrics.density).toInt()
    private fun Float.dp(): Int = (this * resources.displayMetrics.density).toInt()
}
