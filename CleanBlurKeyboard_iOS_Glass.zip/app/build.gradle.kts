plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.riskydwi81.blurkeyboard"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.riskydwi81.blurkeyboard"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}

kotlin {
    jvmToolchain(17)
}
